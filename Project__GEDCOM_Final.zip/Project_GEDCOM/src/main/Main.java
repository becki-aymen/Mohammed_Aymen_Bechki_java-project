package main;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

import parser.GedcomParser;
import service.ConsoleService;

/**
 * Classe principale du projet GEDCOM.
 */
public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Choisissez un fichier GEDCOM :");
        System.out.println("1 - data/begood.ged");
        System.out.println("2 - data/doe.ged");
        System.out.println("3 - data/complet.ged");
        System.out.println("4 - Entrer un autre chemin");
        System.out.print("> ");

        String choice = sc.nextLine();
        Path path = null;

        switch (choice) {
            case "1":
                path = Path.of("data/begood.ged");
                break;
            case "2":
                path = Path.of("data/doe.ged");
                break;
            case "3":
                path = Path.of("data/complet.ged");
                break;
            case "4":
                System.out.print("Entrez le chemin du fichier GED : ");
                path = Path.of(sc.nextLine());
                break;
            default:
                System.out.println("Choix invalide.");
                return;
        }

        if (!Files.exists(path)) {
            System.out.println("❌ Fichier introuvable : " + path);
            return;
        }

        try {
            GedcomParser parser = new GedcomParser();
            parser.parseFile(path);
            parser.linkReferences();

            ConsoleService console = new ConsoleService(parser);
            console.interactive();

        } catch (Exception e) {
            System.out.println("Erreur lors du traitement du fichier GED.");
            System.out.println(e.getMessage());
        }
    }
}
