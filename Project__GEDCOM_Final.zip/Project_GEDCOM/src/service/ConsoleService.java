package service;

import java.util.Scanner;
import parser.GedcomParser;

public class ConsoleService {

    private GedcomParser parser;
    private QueryService qs;

    public ConsoleService(GedcomParser parser) {
        this.parser = parser;
        this.qs = new QueryService(parser);
    }

    public void showSummary() {
        parser.printSummary();
        parser.printErreurs();
    }
    public void demoQueries() { qs.info("John", ""); qs.children("John", ""); qs.siblings("Baby", ""); qs.married("John", "", "Jane", ""); qs.famc("Baby", ""); }
    public void interactive() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Tapez une commande :");
        System.out.println("INFO prenom nom");
        System.out.println("CHILD prenom nom");
        System.out.println("SIBLINGS prenom nom");
        System.out.println("MARRIED prenom1 nom1 prenom2 nom2");
        System.out.println("FAMC prenom nom");
        System.out.println("EXIT");

        while (true) {
            System.out.print("> ");
            String line = sc.nextLine().trim();

            if (line.equalsIgnoreCase("EXIT")) {
                System.out.println("Fin du programme.");
                break;
            }

            String[] parts = line.split("\\s+");

            try {
                String cmd = parts[0].toUpperCase();

                switch (cmd) {

                    case "INFO":
                        if (parts.length < 2) {
                            System.out.println("Usage: INFO prenom nom");
                            break;
                        }
                        qs.info(parts[1], parts.length >= 3 ? parts[2] : "");
                        break;

                    case "CHILD":
                        if (parts.length < 2) {
                            System.out.println("Usage: CHILD prenom nom");
                            break;
                        }
                        qs.children(parts[1], parts.length >= 3 ? parts[2] : "");
                        break;

                    case "SIBLINGS":
                        if (parts.length < 2) {
                            System.out.println("Usage: SIBLINGS prenom nom");
                            break;
                        }
                        qs.siblings(parts[1], parts.length >= 3 ? parts[2] : "");
                        break;

                    case "MARRIED":
                        if (parts.length < 5) {
                            System.out.println("Usage: MARRIED prenom1 nom1 prenom2 nom2");
                            break;
                        }
                        qs.married(parts[1], parts[2], parts[3], parts[4]);
                        break;

                    case "FAMC":
                        if (parts.length < 2) {
                            System.out.println("Usage: FAMC prenom nom");
                            break;
                        }
                        qs.famc(parts[1], parts.length >= 3 ? parts[2] : "");
                        break;

                
                    case "GRAPH":
                        if (parts.length < 2) {
                            System.out.println("Usage: GRAPH prenom nom");
                            break;
                        }
                        qs.showGraph(parts[1], parts.length >= 3 ? parts[2] : "");
                        break;

                    
                    default:
                        System.out.println("Commande inconnue.");
               
                }

            } catch (Exception e) {
                System.out.println("Erreur lors de l'exécution de la commande.");
            }
        }
    }
}
