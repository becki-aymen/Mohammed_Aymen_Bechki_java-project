package service;

import java.util.HashSet;
import java.util.Set;

import model.Famille;
import model.Individu;
import parser.GedcomParser;
/**
 * Service de requêtes permettant de naviguer
 * dans le graphe généalogique.
 */
public class QueryService {

    private GedcomParser parser;

    public QueryService(GedcomParser parser) {
        this.parser = parser;
    }

    public void info(String firstName, String lastName) {

        Individu ind = parser.findIndividuByName(firstName, lastName);

        if (ind == null) {
            System.out.println("❌ Individu non trouvé: " + firstName + " " + lastName);
            return;
        }

        System.out.println("=== INFO ===");
        System.out.println("Nom       : " + ind.getName());
        System.out.println("Sexe      : " + ind.getSex());

        if (ind.getFamilleEnfant() != null)
            System.out.println("Famille enfant : " + ind.getFamilleEnfant());

        System.out.println("Familles parent : " + ind.getFamillesParent());

    }
    public void children(String firstName, String lastName) {

        Individu parent = parser.findIndividuByName(firstName, lastName);

        if (parent == null) {
            System.out.println("❌ Individu non trouvé: " + firstName + " " + lastName);
            return;
        }

        System.out.println("=== CHILDREN of " + firstName + " ===");

        boolean found = false;
        Set<String> printed = new HashSet<>(); // لتجنب التكرار

        for (String famId : parent.getFamillesParent()) {
            Famille fam = parser.getFamilles().get(famId);
            if (fam == null) continue;

            for (String childId : fam.getChildrenIds()) {
                Individu child = parser.getIndividus().get(childId);
                if (child != null && !printed.contains(child.getId())) {
                    System.out.println(child);
                    printed.add(child.getId());
                    found = true;
                }
            }
        }

        if (!found) {
            System.out.println("Aucun enfant trouvé.");
        }
    }
    
    
    public void siblings(String firstName, String lastName) {

        Individu ind = parser.findIndividuByName(firstName, lastName);

        if (ind == null) {
            System.out.println("❌ Individu non trouvé: " + firstName + " " + lastName);
            return;
        }

        String famId = ind.getFamilleEnfant();

        if (famId == null) {
            System.out.println("Aucun frère ou sœur trouvé (pas de famille enfant).");
            return;
        }

        Famille fam = parser.getFamilles().get(famId);
        if (fam == null) {
            System.out.println("Famille introuvable.");
            return;
        }

        System.out.println("=== SIBLINGS of " + firstName + " ===");

        boolean found = false;

        for (String sibId : fam.getChildrenIds()) {
            if (sibId.equals(ind.getId())) continue;

            Individu sib = parser.getIndividus().get(sibId);
            if (sib != null) {
                System.out.println(sib);
                found = true;
            }
        }

        if (!found) {
            System.out.println("Aucun frère ou sœur trouvé.");
        }
    }

    public void married(String firstName1, String lastName1,
            String firstName2, String lastName2) {

Individu p1 = parser.findIndividuByName(firstName1, lastName1);
Individu p2 = parser.findIndividuByName(firstName2, lastName2);

if (p1 == null || p2 == null) {
System.out.println("❌ Un ou les deux individus sont introuvables.");
return;
}

for (Famille fam : parser.getFamilles().values()) {
String h = fam.getHusbandId();
String w = fam.getWifeId();

if ((p1.getId().equals(h) && p2.getId().equals(w)) ||
    (p1.getId().equals(w) && p2.getId().equals(h))) {

    System.out.println("✅ " + firstName1 + " est marié(e) avec " + firstName2);
    return;
}
}

System.out.println("❌ " + firstName1 + " n'est pas marié(e) avec " + firstName2);
}
    public void famc(String firstName, String lastName) {

        Individu child = parser.findIndividuByName(firstName, lastName);

        if (child == null) {
            System.out.println("❌ Individu non trouvé: " + firstName);
            return;
        }

        String famId = child.getFamilleEnfant();
        if (famId == null) {
            System.out.println("❌ Cet individu n'a pas de famille connue.");
            return;
        }

        Famille fam = parser.getFamilles().get(famId);
        if (fam == null) {
            System.out.println("❌ Famille introuvable.");
            return;
        }

        System.out.println("=== FAMC de " + firstName + " ===");

        // Père
        if (fam.getHusbandId() != null) {
            Individu father = parser.getIndividus().get(fam.getHusbandId());
            System.out.println("Father: " + father);
        }

        // Mère
        if (fam.getWifeId() != null) {
            Individu mother = parser.getIndividus().get(fam.getWifeId());
            System.out.println("Mother: " + mother);
        }

        // Frères et sœurs
        System.out.println("Siblings:");
        boolean found = false;
        for (String sibId : fam.getChildrenIds()) {
            if (!sibId.equals(child.getId())) {
                Individu sib = parser.getIndividus().get(sibId);
                if (sib != null) {
                    System.out.println("- " + sib);
                    found = true;
                }
            }
        }

        if (!found) {
            System.out.println("Aucun frère ou sœur.");
        }
    }
    
    public void showGraph(String firstName, String lastName) {

        Individu ind = parser.findIndividuByName(firstName, lastName);
        if (ind == null) {
            System.out.println("❌ Individu non trouvé.");
            return;
        }

        System.out.println("=== GRAPHE GÉNÉALOGIQUE ===");
        System.out.println(ind.getName());

        for (String famId : ind.getFamillesParent()) {
            Famille fam = parser.getFamilles().get(famId);
            if (fam == null) continue;

            System.out.println(" └─ Famille " + famId);

            for (String childId : fam.getChildrenIds()) {
                Individu child = parser.getIndividus().get(childId);
                if (child != null) {
                    System.out.println("     └─ Enfant : " + child.getName());
                }
            }
        }
    }}