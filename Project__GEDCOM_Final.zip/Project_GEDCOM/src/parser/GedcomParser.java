package parser;  // تأكد أن الملف داخل مجلد parser

import model.Individu;
import model.Plac;
import model.Sex;
import model.Date;
import model.Famille;
import exceptions.GedcomException;
import exceptions.IdentifiantInvalideException;
import exceptions.LienManquantException;
import exceptions.IncoherenceException;
import exceptions.LienInverseManquantException;

import java.util.List;
import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Map;
import exceptions.CycleException;
import exceptions.DuplicateIdentifiantException;

import java.util.HashSet;
import java.util.Set;

//import java.util.jar.Attributes.Name;   ← احذف هذا السطر
import model.Name;   // ← استورد Name من الحزمة model

import java.util.HashMap;
import java.io.Serializable;


import java.io.*;
/**
 * GedcomParser
 * ------------
 * Classe principale chargée de :
 * - lire un fichier GEDCOM
 * - créer les individus et les familles
 * - construire le graphe généalogique
 * - détecter les incohérences
 * - permettre la sérialisation du graphe
 */

public class GedcomParser implements Serializable {
	private static final long serialVersionUID = 1L;

	public void parse(String path) throws Exception {
		BufferedReader br = new BufferedReader(new FileReader(path));
		String line;


		Individu currentInd = null;
		Famille currentFam = null;


		while ((line = br.readLine()) != null) {
			line = line.trim();
			if (line.isEmpty()) continue; // تجاهل السطر الفارغ

			String[] parts = line.split(" ", 3);
			int level = Integer.parseInt(parts[0]);
			String tag = parts.length > 2 ? parts[2] : "";

			if (level == 0) {

			    if (line.contains("INDI")) {
			        String id = parts[1];

			        // 1️⃣ تحقق من صحة ID
			        if (!isValidIndividuId(id)) {
			            erreurs.add(new IdentifiantInvalideException(
			                "Identifiant individu invalide: " + id
			            ));
			            currentInd = null;
			            continue;
			        }

			        // 2️⃣ تحقق من التكرار
			        if (individus.containsKey(id)) {
			            erreurs.add(new DuplicateIdentifiantException(
			                "Identifiant individu dupliqué: " + id
			            ));
			            currentInd = null;
			            continue;
			        }

			        // 3️⃣ إنشاء الفرد
			        currentInd = new Individu(id);
			        individus.put(id, currentInd);
			        currentFam = null;
			    }

			    else if (line.contains("FAM")) {
			        String id = parts[1];

			        if (!isValidFamilleId(id)) {
			            erreurs.add(new IdentifiantInvalideException(
			                "Identifiant famille invalide: " + id
			            ));
			            currentFam = null;
			            continue;
			        }

			        // تحقق من التكرار
			        if (familles.containsKey(id)) {
			            erreurs.add(new DuplicateIdentifiantException(
			                "Identifiant famille dupliqué: " + id
			            ));
			            currentFam = null;
			            continue;
			        }

			        currentFam = new Famille(id);
			        familles.put(id, currentFam);
			        currentInd = null;
			    }
			}  // ✅ هذا القوس كان ناقص

			else if (level == 1 && currentInd != null) {
				if (parts[1].equals("NAME")) currentInd.setName(new Name(tag));
				else if (parts[1].equals("SEX")) currentInd.setSex(new Sex(tag));
				else if (parts[1].equals("BIRT")) continue; // next level handles it
			}


			else if (level == 2 && currentInd != null) {
				if (parts[1].equals("DATE")) currentInd.setBirthDate(new Date(tag));
				else if (parts[1].equals("PLAC")) currentInd.setBirthPlace(new Plac(tag));
			}


			else if (level == 1 && currentFam != null) {
				if (parts[1].equals("HUSB")) currentFam.setHusband(parts[2]);
				else if (parts[1].equals("WIFE")) currentFam.setWife(parts[2]);
				else if (parts[1].equals("CHIL")) currentFam.addChild(parts[2]);
			}
		}


		br.close();
	}

	public Map<String, Individu> getIndividus() { return individus; }
	public Map<String, Famille> getFamilles() { return familles; }
	/**
	 * Lance le parsing d'un fichier GEDCOM.
	 * @param path chemin du fichier GED
	 * @throws Exception en cas d'erreur de lecture
	 */

	public void parseFile(Path path) throws Exception {
		parse(path.toString());
	}



	private Map<String, Individu> individus = new HashMap<>();
	private Map<String, Famille> familles = new HashMap<>();
	private List<GedcomException> erreurs = new ArrayList<>(); // لوج الأخطاء




	public void printSummary() {
		System.out.println("Individus:");
		individus.values().forEach(System.out::println);
		System.out.println("Familles:");
		familles.values().forEach(System.out::println);
	}

	/**
	 * Construit les liens entre individus et familles
	 * et détecte les incohérences du graphe.
	 */
	public void linkReferences() {
		for (Famille fam : familles.values()) {
			// الزوج
			if (fam.getHusbandId() != null && individus.containsKey(fam.getHusbandId())) {
				Individu husband = individus.get(fam.getHusbandId());
				husband.addFamilleParent(fam.getId());
				try { husband.checkCoherence("Father"); } 
				catch (IncoherenceException e) { erreurs.add(e); }
			}
			// الزوجة
			if (fam.getWifeId() != null && individus.containsKey(fam.getWifeId())) {
				Individu wife = individus.get(fam.getWifeId());
				wife.addFamilleParent(fam.getId());
				try { wife.checkCoherence("Mother"); } 
				catch (IncoherenceException e) { erreurs.add(e); }
			}
			// الأطفال
			for (String childId : fam.getChildrenIds()) {
				if (individus.containsKey(childId)) {
					Individu child = individus.get(childId);
					   if (child.getFamilleEnfant() != null &&
			                    !child.getFamilleEnfant().equals(fam.getId())) {

			                    erreurs.add(new LienInverseManquantException(
			                        "Lien inverse manquant: enfant " + child.getId()
			                        + " est déjà lié à la famille " + child.getFamilleEnfant()
			                        + " mais apparaît comme CHIL dans " + fam.getId()
			                    ));
			                }
					child.setFamilleEnfant(fam.getId());
					
					// لاحقًا يمكن التحقق من تاريخ الميلاد بالنسبة للوالدين
				} else {
					erreurs.add(new LienManquantException("CHIL manquant: " + childId + " dans famille " + fam.getId()));
				}
			}
		}
		
		// 🚨 كشف الدورات في الرسم البياني
		for (Individu ind : individus.values()) {
		    try {
		        detectCycleFromIndividu(
		            ind.getId(),
		            ind.getId(),
		            new HashSet<>()
		        );
		    } catch (CycleException e) {
		        erreurs.add(e);
		    }
		}
	}
	private boolean isValidIndividuId(String id) {
	    return id != null && id.matches("@I\\d+@");
	}

	private boolean isValidFamilleId(String id) {
	    return id != null && id.matches("@F\\d+@");
	}

	// طباعة ملخص الأخطاء
	public void printErreurs() {
		if (erreurs.isEmpty()) {
			System.out.println("Pas d'erreurs détectées.");
		} else {
			System.out.println("Erreurs détectées:");
			for (GedcomException e : erreurs) {
				System.out.println("- " + e.getMessage());
			}
		}
	}
	
	private void detectCycleFromIndividu(
	        String startIndId,
	        String currentIndId,
	        Set<String> visited
	) throws CycleException {

	    if (visited.contains(currentIndId)) {
	        throw new CycleException(
	            "Cycle détecté: individu " + startIndId + " est ancêtre de lui-même"
	        );
	    }

	    visited.add(currentIndId);

	    Individu current = individus.get(currentIndId);
	    if (current == null) return;

	    // يمر عبر العائلات التي يكون فيها الفرد والدًا
	    for (String famId : current.getFamillesParent()) {
	        Famille fam = familles.get(famId);
	        if (fam == null) continue;

	        // ينتقل إلى الأطفال
	        for (String childId : fam.getChildrenIds()) {
	            detectCycleFromIndividu(startIndId, childId, visited);
	        }
	    }
	}

	// ✅ تنظيف النص للمقارنة (حروف صغيرة + إزالة الفراغات الزائدة)
	private String normalize(String s) {
	    if (s == null) return "";
	    return s.trim().toLowerCase();
	}

	// ✅ البحث عن فرد بالاسم واللقب
	/**
	 * Recherche un individu par prénom et nom.
	 * @param firstName prénom
	 * @param lastName nom
	 * @return Individu trouvé ou null
	 */
	public Individu findIndividuByName(String firstName, String lastName) {
	    String fn = normalize(firstName);
	    String ln = normalize(lastName);

	    for (Individu ind : individus.values()) {
	        if (ind.getName() == null) continue;

	        String indFn = normalize(ind.getName().getFirstName());
	        String indLn = normalize(ind.getName().getLastName());

	     // إذا الاسم واللقب موجودان
	        if (!ln.isEmpty()) {
	            if (indFn.equals(fn) && indLn.equals(ln)) {
	                return ind;
	            }
	        }
	        // إذا المستخدم أدخل الاسم فقط
	        else {
	            if (indFn.equals(fn)) {
	                return ind;
	            }
	        }
	       
	    }
	    return null; // غير موجود
	}
	/**
	 * Sauvegarde le graphe généalogique dans un fichier.
	 * @param file nom du fichier
	 * @throws Exception erreur d'écriture
	 */
	public void saveToFile(String filename) throws IOException {
	    try (ObjectOutputStream oos =
	                 new ObjectOutputStream(new FileOutputStream(filename))) {
	        oos.writeObject(this);
	    }
	}
	/**
	 * Charge un graphe généalogique depuis un fichier.
	 * @param file nom du fichier
	 * @return GedcomParser chargé
	 * @throws Exception erreur de lecture
	 */
	public static GedcomParser loadFromFile(String filename)
	        throws IOException, ClassNotFoundException {

	    try (ObjectInputStream ois =
	                 new ObjectInputStream(new FileInputStream(filename))) {
	        return (GedcomParser) ois.readObject();
	    }
	}


}
