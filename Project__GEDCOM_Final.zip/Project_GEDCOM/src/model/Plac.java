package model;


public class Plac extends Tag {
	private String place;


	public Plac(String rawValue) {
		super(rawValue);
	}


	@Override
	protected void parse(String value) {
		place = value;
	}


	public String getPlace() { return place; }


	@Override
	public String toString() { return place; }
}