package model;

/**
 * Sex: يرث Tag ويقوم بعملية تحقق بسيطة (M أو F أو null)
 */
public class Sex extends Tag {
	private String sex;


	public Sex(String rawValue) {
		super(rawValue);
	}


	@Override
	protected void parse(String value) {
		if (value == null) return;
		if (value.equals("M") || value.equals("F")) {
			sex = value;
		} else {
			sex = "U"; // Unknown
		}
	}


	public String getSex() { return sex; }


	@Override
	public String toString() { return sex; }
}
