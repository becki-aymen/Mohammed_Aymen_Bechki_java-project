package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import exceptions.IncoherenceException;
/**
 * Affiche les informations d'un individu.
 */
public class Individu implements Serializable {

    private static final long serialVersionUID = 1L;
    private String id;
    private Name name;
    private Sex sex;
    private Date birthDate;
    private Plac birthPlace;

    // علاقات العائلة
    private String familleEnfant;         // FAMC
    private List<String> famillesParent;  // FAMS

    public Individu(String id) {
        this.id = id;
        this.famillesParent = new ArrayList<>();
    }

    // Setters/Getters
    public void setName(Name name) { this.name = name; }
    public void setSex(Sex sex) { this.sex = sex; }
    public void setBirthDate(Date birthDate) { this.birthDate = birthDate; }
    public void setBirthPlace(Plac birthPlace) { this.birthPlace = birthPlace; }
    public String getId() { return id; }

    public String getFamilleEnfant() { return familleEnfant; }
    public void setFamilleEnfant(String familleEnfant) { this.familleEnfant = familleEnfant; }

    public List<String> getFamillesParent() { return famillesParent; }
    public void addFamilleParent(String familleParent) { this.famillesParent.add(familleParent); }

    // --- التحقق من الاتساق ---
    public void checkCoherence(String role) throws IncoherenceException {

        if (sex == null) return; // 🔥 الحل هنا

        if ("Mother".equals(role) && "M".equals(sex.getSex())) {
            throw new IncoherenceException(
                "Incohérence: individu " + id + " ne peut pas être mère."
            );
        }

        if ("Father".equals(role) && "F".equals(sex.getSex())) {
            throw new IncoherenceException(
                "Incohérence: individu " + id + " ne peut pas être père."
            );
        }
    }

    public Name getName() { 
        return name; 
    }
    public Sex getSex() {
        return sex;
    }
    
    @Override
    public String toString() {
        return "Individu{" +
                "id='" + id + '\'' +
                ", name=" + name +
                ", sex=" + sex +
                ", birthDate=" + birthDate +
                ", birthPlace=" + birthPlace +
                ", familleEnfant=" + familleEnfant +
                ", famillesParent=" + famillesParent +
                '}';
    }


}
