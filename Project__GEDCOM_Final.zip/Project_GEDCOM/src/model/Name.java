package model;

/**
 * Name: يرث Tag ويحلل اسم الشخص (prénom + nom / أو الاسم الكامل)
 * GEDCOM عادة يعطي الاسم بصيغة: "John /Doe/" لكن قد يكون أشكال أخرى.
 */
public class Name extends Tag {
	private String firstName;
	private String lastName;


	public Name(String rawValue) {
		super(rawValue);
	}


	@Override
	protected void parse(String value) {
		if (value == null) return;
		String cleaned = value.replace("/", " ").trim();
		String[] parts = cleaned.split(" ");
		if (parts.length > 1) {
			firstName = parts[0];
			lastName = parts[parts.length - 1];
		} else {
			firstName = cleaned;
			lastName = "";
		}
	}


	public String getFirstName() { return firstName; }
	public String getLastName() { return lastName; }


	@Override
	public String toString() {
		return firstName + " " + lastName;
	}
}