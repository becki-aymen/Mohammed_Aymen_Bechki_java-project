package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 * Représente une famille (père, mère, enfants).
 */
public class Famille implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;
    private String husbandId;
    private String wifeId;
    private List<String> childrenIds = new ArrayList<>();

    public Famille(String id) {
        this.id = id;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getHusbandId() {
        return husbandId;
    }

    public String getWifeId() {
        return wifeId;
    }

    public List<String> getChildrenIds() {
        return childrenIds;
    }

    // Setters
    public void setId(String id) {
        this.id = id;
    }

    public void setHusbandId(String husbandId) {
        this.husbandId = husbandId;
    }

    public void setWifeId(String wifeId) {
        this.wifeId = wifeId;
    }

    public void setChildrenIds(List<String> childrenIds) {
        this.childrenIds = childrenIds;
    }

    // Methods to add individual children
    public void addChild(String childId) {
        this.childrenIds.add(childId);
    }

    public void setHusband(String id) {
        this.husbandId = id;
    }

    public void setWife(String id) {
        this.wifeId = id;
    }

    @Override
    public String toString() {
        return "Famille{" +
                "id='" + id + '\'' +
                ", husband='" + husbandId + '\'' +
                ", wife='" + wifeId + '\'' +
                ", children=" + childrenIds +
                '}';
    }
}
