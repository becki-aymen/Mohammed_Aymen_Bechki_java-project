package model;

import java.io.Serializable;

/**
 * Tag: فئة مجردة تمثل أي TAG في GEDCOM له قيمة نصية.
 * تُورّث منها Name, Sex, GedcomDate, Plac ...
 */
public abstract class Tag implements Serializable {

    private static final long serialVersionUID = 1L;
	protected String rawValue;


	public Tag(String rawValue) {
		this.rawValue = rawValue;
		parse(rawValue);
	}


	protected abstract void parse(String value);


	public String getRawValue() {
		return rawValue;
	}
	@Override
	public abstract String toString();
}