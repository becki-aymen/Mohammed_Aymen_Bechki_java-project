package model;


public class Date extends Tag {
 protected void name() {
	
} String normalized;


public Date(String rawValue) {
super(rawValue);
}


@Override
protected void parse(String value) {
if (value == null) return;
normalized = value; // TODO: implement real GEDCOM date parsing
}


public String getNormalized() { return normalized; }


@Override
public String toString() { return normalized; }
}