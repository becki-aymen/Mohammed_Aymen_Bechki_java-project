package exceptions;

public class DuplicateIdentifiantException extends GedcomException {

    public DuplicateIdentifiantException(String message) {
        super("ID_DUPLIQUE", message);
    }
}
