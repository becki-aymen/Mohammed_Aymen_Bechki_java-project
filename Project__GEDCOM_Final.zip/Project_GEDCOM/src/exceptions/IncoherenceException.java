package exceptions;

public class IncoherenceException extends GedcomException {
    public IncoherenceException(String message) {
        super("INCOHERENCE", message);
    }
}
