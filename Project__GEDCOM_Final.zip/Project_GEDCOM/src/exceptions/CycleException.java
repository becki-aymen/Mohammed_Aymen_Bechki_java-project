package exceptions;

public class CycleException extends GedcomException {

    public CycleException(String message) {
        super("CYCLE_DETECTE", message);
    }
}
