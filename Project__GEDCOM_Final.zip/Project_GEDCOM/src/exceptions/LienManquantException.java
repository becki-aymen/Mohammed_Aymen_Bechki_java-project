package exceptions;

public class LienManquantException extends GedcomException {
    public LienManquantException(String message) {
        super("LIEN_MANQUANT", message);
    }
}
