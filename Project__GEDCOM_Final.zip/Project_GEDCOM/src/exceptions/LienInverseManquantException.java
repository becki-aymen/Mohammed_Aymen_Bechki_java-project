package exceptions;

public class LienInverseManquantException extends GedcomException {

    public LienInverseManquantException(String message) {
        super("LIEN_INVERSE_MANQUANT", message);
    }
}
