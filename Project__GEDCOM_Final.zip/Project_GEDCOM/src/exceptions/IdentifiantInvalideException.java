package exceptions;

public class IdentifiantInvalideException extends GedcomException {
    public IdentifiantInvalideException(String message) {
        super("ID_INVALIDE", message);
    }
}
