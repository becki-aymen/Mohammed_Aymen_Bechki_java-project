package exceptions;

public class GedcomException extends Exception {
    private String code;

    public GedcomException(String message) {
        super(message);
    }

    public GedcomException(String code, String message) {
        super(message);
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
